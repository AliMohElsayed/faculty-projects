<?php
// Start session
session_start();

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Sign Up
if (isset($_POST['signup'])) {
    // Sanitize user input to prevent SQL injection
    $Fname = $conn->real_escape_string($_POST['Fname']);
    $Lname = $conn->real_escape_string($_POST['Lname']);
    $email = $conn->real_escape_string($_POST['email']);
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $address = $conn->real_escape_string($_POST['address']);
    $job_title = $conn->real_escape_string($_POST['job_title']);
    $password = $conn->real_escape_string($_POST['password']);

    $sql = "INSERT INTO `user`(`Fname`, `Lname`, `email`, `mobile`, `address`, `job_title`, `password`) 
            VALUES ('$Fname','$Lname','$email','$mobile','$address','$job_title','$password')";

    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location: index.html?msg=New record created successfully");
        exit();
    } else {
        echo "Failed to sign up: " . mysqli_error($conn);
    }
}

// Log In
if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $sql = "SELECT * FROM user WHERE email = '$email' and password = '$password'";

    $result = mysqli_query($conn,$sql);      
    $count = mysqli_num_rows($result);

    if($count == 1) {
        // Set session variable
        $_SESSION['login_user'] = $email;
        header("location: index.html");
    } else {
        $error = "Your Login Name or Password is invalid";
    }
}

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="css/login&signup.css">
    <style>
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
        }
    </style>
    <title>GRAND ROYAL</title>
</head>
<body>
 <div class="wrapper">
    <nav class="nav">
        <div class="nav-logo">
            <p>GRAND ROYAL</p>
        </div>
        <div class="nav-menu" id="navMenu">
            <ul>
                <li><a href="index.html" class="link active">Home</a></li>
                <li><a href="about.html" class="link">About</a></li>
                <li><a href="service.html" class="link">Service</a></li>
                <li><a href="car.html" class="link">Cars</a></li>
                <li><a href="team.html" class="link">Team</a></li>
                <li><a href="contact.html" class="link">Contact</a></li>
            </ul>
        </div>
        <div class="nav-button">
            <button class="btn white-btn" id="loginBtn" onclick="login()">Log In</button>
            <button class="btn" id="signupBtn" onclick="register()">Sign Up</button>
        </div>
        <div class="nav-menu-btn">
            <i class="bx bx-menu" onclick="myMenuFunction()"></i>
        </div>
    </nav>
<!----------------------------- Form box ----------------------------------->    
    <div class="form-box">
        
        <!------------------- Log In form -------------------------->
        <div class="login-container" id="login">
    <div class="top">
        <span>Don't have an account? <a href="#" onclick="register()">Sign Up</a></span>
        <header>Log In</header>
    </div>
    <form action="signup_login.php" method="post">

        <div class="input-box">
            <input type="text" class="input-field" name="email" placeholder="Email">
            <i class="bx bx-user"></i>
        </div>
        <div class="input-box">
            <input type="password" class="input-field" name="password" placeholder="Password">
            <i class="bx bx-lock-alt"></i>
        </div>
        <div class="input-box">
            <input type="submit" class="submit" name="login" value="Log In">
        </div>
    </form>
    <div class="two-col">
        <div class="one">
            <input type="checkbox" id="login-check">
            <label for="login-check"> Remember Me</label>
        </div>
        <div class="two">
            <label><a href="#">Forgot password?</a></label>
        </div>
    </div>
    <?php if (!empty($error)) { ?>
    <div class="error-message"><?php echo $error; ?></div>
<?php } ?>
</div>

        <!------------------- Sign Up form -------------------------->
        <div class="signup-container" id="signup">
            <div class="top">
                <span>Have an account? <a href="#" onclick="login()">Log In</a></span>
                <header>Sign Up</header>
            </div>
            <form action="" method="post">
                <div class="two-forms">
                    <div class="input-box">
                        <input type="text" class="input-field" name="Fname" placeholder="Firstname">
                        <i class="bx bx-user"></i>
                    </div>
                    <div class="input-box">
                        <input type="text" class="input-field" name="Lname" placeholder="Lastname">
                        <i class="bx bx-user"></i>
                    </div>
                </div>
                <div class="input-box">
                    <input type="text" class="input-field" name="email" placeholder="Email">
                    <i class="bx bx-envelope"></i>
                </div>
                <div class="input-box">
                    <input type="tel" class="input-field" name="mobile" placeholder="Phone Number">
                    <i class='bx bx-phone'></i>
                </div>
                <div class="input-box">
                    <input type="text" class="input-field" name="job_title" placeholder="Job Title">
                    <i class='bx bx-briefcase'></i>
                </div>
                <div class="input-box">
                    <input type="text" class="input-field" name="address" placeholder="Your Address">
                    <i class='bx bx-home-alt'></i>
                </div>
                <div class="input-box">
                    <input type="password" class="input-field" name="password" placeholder="Password">
                    <i class="bx bx-lock-alt"></i>
                </div>
                <div class="input-box">
                    <input type="submit" class="submit" name="signup" value="Register">
                </div>
            </form>
            <div class="two-col">
                <div class="one">
                    <input type="checkbox" id="signup-check">
                    <label for="signup-check"> Remember Me</label>
                </div>
                <div class="two">
                    <label><a href="#">Terms & conditions</a></label>
                </div>
            </div>
        </div>
    </div>
</div>   
<script>
   
   function myMenuFunction() {
    var i = document.getElementById("navMenu");
    if(i.className === "nav-menu") {
        i.className += " responsive";
    } else {
        i.className = "nav-menu";
    }
   }
 
</script>
<script>
    var a = document.getElementById("loginBtn");
    var b = document.getElementById("signupBtn");
    var x = document.getElementById("login");
    var y = document.getElementById("signup");
    function login() {
        x.style.left = "4px";
        y.style.right = "-520px";
        a.className += " white-btn";
        b.className = "btn";
        x.style.opacity = 1;
        y.style.opacity = 0;
    }
    function register() {
        x.style.left = "-510px";
        y.style.right = "5px";
        a.className = "btn";
        b.className += " white-btn";
        x.style.opacity = 0;
        y.style.opacity = 1;
    }
</script>
</body>
</html>
