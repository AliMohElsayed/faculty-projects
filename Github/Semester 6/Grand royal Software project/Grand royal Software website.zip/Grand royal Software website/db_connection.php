<?php
// Start session
session_start();

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Display a user-friendly error message
    die("Connection failed. Please try again later.");
}

// Error reporting (optional, for development/debugging)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
