<?php
include 'db_connection.php';

// Get form data
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$mobile_number = $_POST['mobile_number'];
$pickup_location = $_POST['pickup_location'];
$drop_location = $_POST['drop_location'];
$pickup_date = $_POST['pickup_date'];
$pickup_time = $_POST['pickup_time'];
$special_request = $_POST['special_request'];

// Prepare and bind SQL statement
$stmt = $conn->prepare("INSERT INTO booking_details (first_name, last_name, email, mobile_number, pickup_location, drop_location, pickup_date, pickup_time, special_request) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssss", $first_name, $last_name, $email, $mobile_number, $pickup_location, $drop_location, $pickup_date, $pickup_time, $special_request);

// Execute SQL statement
$stmt->execute();

// Close statement and database connection
$stmt->close();
$conn->close();

// Redirect back to the booking page or any other page
header("Location: booking.html");
exit();
?>
