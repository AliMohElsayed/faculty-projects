<?php
// Include the database connection script
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form input data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Check if the table exists in the database
    $tableName = 'contact_form_submissions'; // Replace 'your_table_name' with the actual table name
    $checkTableExistsQuery = "SHOW TABLES LIKE '$tableName'";
    $tableExistsResult = mysqli_query($conn, $checkTableExistsQuery);

    if ($tableExistsResult) {
        // Table exists, insert the form data into the database
        $sql = "INSERT INTO $tableName (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
        
        if (mysqli_query($conn, $sql)) {
        // Data inserted successfully
        mysqli_close($conn);
        // Redirect to the index page
        header("Location: index.html");
        exit(); // Stop further execution
        } else {
            // Error inserting data
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        // Table does not exist, display an error message
        echo "Error: Table '$tableName' does not exist.";
    }
}

// Close the database connection
mysqli_close($conn);
?>
<?php

<?php
// Include the database connection script
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form input data
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $mobile_number = mysqli_real_escape_string($conn, $_POST['mobile_number']);
    $pickup_location = mysqli_real_escape_string($conn, $_POST['pickup_location']);
    $drop_location = mysqli_real_escape_string($conn, $_POST['drop_location']);
    $pickup_date = mysqli_real_escape_string($conn, $_POST['pickup_date']);
    $pickup_time = mysqli_real_escape_string($conn, $_POST['pickup_time']);
    $adult = mysqli_real_escape_string($conn, $_POST['adult']);
    $child = mysqli_real_escape_string($conn, $_POST['child']);
    $special_request = mysqli_real_escape_string($conn, $_POST['special_request']);

    // Insert the form data into the database
    $sql = "INSERT INTO booking_details (first_name, last_name, email, mobile_number, pickup_location, drop_location, pickup_date, pickup_time, adult, child, special_request) 
            VALUES ('$first_name', '$last_name', '$email', '$mobile_number', '$pickup_location', '$drop_location', '$pickup_date', '$pickup_time', '$adult', '$child', '$special_request')";
    
    if (mysqli_query($conn, $sql)) {
        // Data inserted successfully
        header("Location: index.html"); // Redirect to index.html
        exit();
    } else {
        // Error inserting data
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    // If the form is not submitted
    echo "Form not submitted!";
}

// Close the database connection
mysqli_close($conn);
?>